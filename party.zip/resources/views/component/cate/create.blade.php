@extends('component.includs.index')
@section('home')

<form action="{{route('cate.store')}}" method="post" enctype="multipart/form-data">
    @csrf
<div class="container">
   
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Name</label>
    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="name" name="name">
  </div>

  <div class="input-group mb-3">
    <label class="input-group-text" for="inputGroupFile01">Upload</label>
    <input type="file" class="form-control" id="inputGroupFile01" name="image">
  </div>

        <div class="mb-3">
          <label for="exampleInputEmail1" class="form-label"> Description</label>
          <input type="text" class="form-control" id="exampleInputEmail1" placeholder="" name="description">
        </div>       
    
        

          <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">Date</label>
            <input type="text" class="form-control" id="exampleInputPassword1"name="date" >
           
          </div>

         
       


        <button type="submit" class="btn btn-primary">Submit</button>
</div>






</form>
@endsection

