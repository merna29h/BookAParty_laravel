
<?php $__env->startSection('home'); ?>



<table class="table">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Name</th>
        <th scope="col">Logo</th>
        <th scope="col">Descraption</th>
        <th scope="col">Date</th>
        <th scope="col">Options</th>
       

      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     

      <tr>
        <td> <?php echo e($Categories ->id); ?></td>
        <td> <?php echo e($Categories->name); ?></td>
        <td><img src="<?php echo e(asset('category/'.$Categories->logo)); ?>" width="50px"></td>
        <td> <?php echo e($Categories->description); ?></td>
      
        <td> <?php echo e($Categories->date); ?></td>

         <td>       
         <a class="btn btn-info"  href="<?php echo e(route('cate.edit',$Categories->id)); ?>" >Edit</a>
          <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($Categories->id); ?>">Delete</button> 
          
        </td> 
       
      </tr>
     <!-- Modal -->
<div class="modal fade" id="exampleModal<?php echo e($Categories->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <form action="<?php echo e(route('cate.destroy',$Categories->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('delete'); ?>
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        are you sure you want delete <?php echo e($Categories->name); ?>

     </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">delete</button>
      </div>
    </div>
  </div>
  </form>
 
        

</div>

     
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </tbody>
  </table>
  


<?php $__env->stopSection(); ?>


<?php echo $__env->make('component.includs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\New folder\party\resources\views/component/cate/index.blade.php ENDPATH**/ ?>