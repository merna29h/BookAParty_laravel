<!doctype html>
<html class="no-js" lang="zxx">

<?php echo $__env->make('component.front end.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>


    <!-- header-start -->
    <?php echo $__env->make('component.front end.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- header-end -->


<div class="div">
    <?php echo $__env->yieldContent('home'); ?>
</div>


    <!-- footer_start  -->
    <?php echo $__env->make('component.front end.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- footer_end  -->

    <!-- JS here -->
    <?php echo $__env->make('component.front end.includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- JS end -->
</body>

</html><?php /**PATH C:\xampp\htdocs\laravel\New folder\party\resources\views/component/front end/includes/main.blade.php ENDPATH**/ ?>