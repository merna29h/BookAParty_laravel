<div class="py-6 px-6 text-center">
    <p class="mb-0 fs-4">Design and Developed by <a href="https://attractionme.com/" target="_blank" class="pe-1 text-primary text-decoration-underline">Party.com</a> Distributed by <a href="https://attractionme.com">PARTY</a></p>
  </div><?php /**PATH C:\xampp\htdocs\laravel\New folder\party\resources\views/component/includs/footer.blade.php ENDPATH**/ ?>