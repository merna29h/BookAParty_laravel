<!doctype html>
<html lang="en">

<?php echo $__env->make('component.includs.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <!--  Body Wrapper -->
    <div class="page-wrapper" id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
    data-sidebar-position="fixed" data-header-position="fixed">
    
    <!-- Sidebar Start -->
    <?php echo $__env->make('component.includs.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--  Sidebar End -->
    <!--  Main wrapper -->
    <div class="body-wrapper">
      <!--  Header Start -->
      <?php echo $__env->make('component.includs.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!--  Header End -->
      <!--  Body End -->
      
        <div class="container-fluid">
  
         <?php echo $__env->yieldContent('home'); ?>
        </div>
      <!--  Body End -->

      <!--  Footer Start -->
      <?php echo $__env->make('component.includs.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Footer End -->
      </div>
      </div>
      <?php echo $__env->make('component.includs.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </body>
    </html><?php /**PATH C:\xampp\htdocs\laravel\New folder\party\resources\views/component/includs/index.blade.php ENDPATH**/ ?>