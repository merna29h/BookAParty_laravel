
<?php $__env->startSection('home'); ?>

<form action="<?php echo e(route('evant.update',$evant->id)); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
<div class="container">
   
  <select class="form-select form-select-lg mb-3" aria-label=".form-select-lg example" name="name">

    <option value=""> Name Singer</option>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($category->id); ?>"> <?php echo e($category->name); ?> </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>

          <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Description</label>
            <input type="text" class="form-control" id="exampleInputEmail1" placeholder="" name="description"
            value="<?php echo e($evant->description); ?>">
          </div>

          <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">Date</label>
            <input type="text" class="form-control" id="exampleInputPassword1" name="date"  value="<?php echo e($evant->date); ?>">
           
          </div>

          <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">Price</label>
            <input type="text" class="form-control" id="exampleInputPassword1" name="price"  value="<?php echo e($evant->price); ?>">
           
          </div>

          <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">Ticket</label>
            <input type="text" class="form-control" id="exampleInputPassword1" name="ticket"  value="<?php echo e($evant->ticket); ?>">
           
          </div>
        <button type="submit" class="btn btn-primary">Submit</button>
</div>
</form>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('component.includs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\New folder\party\resources\views/component/evant/edit.blade.php ENDPATH**/ ?>