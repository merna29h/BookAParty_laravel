
<?php $__env->startSection('home'); ?>

<form action="<?php echo e(route('cate.update',$cate->id)); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
<div class="container">
   
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Name</label>
    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="name" name="name"
    value="<?php echo e($cate->name); ?>">
  </div>

          <div class="input-group mb-3">
            <label class="input-group-text" for="inputGroupFile01">Upload</label>
            <img src="<?php echo e(asset('category/'.$cate->logo)); ?>" width="50px">
            <input type="file" class="form-control" id="inputGroupFile01" name="image"
            value="<?php echo e($cate->logo); ?>">
          </div>

          <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Description</label>
            <input type="text" class="form-control" id="exampleInputEmail1" placeholder="" name="description"
            value="<?php echo e($cate->description); ?>">
          </div>

          <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">Date</label>
            <input type="text" class="form-control" id="exampleInputPassword1" name="date"  value="<?php echo e($cate->date); ?>">
           
          </div>
        <button type="submit" class="btn btn-primary">Submit</button>
</div>
</form>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('component.includs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\New folder\party\resources\views/component/cate/edit.blade.php ENDPATH**/ ?>