
<?php $__env->startSection('home'); ?>

<table class="table">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col"> Party Name</th>
       <th scope="col">User Name</th>
        <th scope="col">Email</th>
        <th scope="col">Phone</th>
        <th scope="col">Book Number</th>
        <th scope="col">Stutes</th>
        <th scope="col">Operation</th>

       

      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $reserves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     

      <tr>
        <td> <?php echo e($reserve ->id); ?></td>
        <td> <?php echo e($reserve->name); ?></td>
        <td> <?php echo e($reserve->email); ?></td>
        <td> <?php echo e($reserve->phone); ?></td>
        <td> <?php echo e($reserve->number_ticket); ?></td>
        <td> <?php echo e($reserve->event_id); ?></td>
         <td><?php echo e($reserve->approve == 0 ? 'pending' : 'Approved'); ?></td>
         <td>
          <form action="<?php echo e(route('reserve.update',$reserve->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <button class="btn btn-success" name="approve" value="1">Approve</button>

            <button class="btn btn-danger" name="approve" value="0">Pendding</button>

             
          </form>
          
        </td>  
       
      </tr>
 
 
        


     
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </tbody>
  </table>
  






<?php $__env->stopSection(); ?>
<?php echo $__env->make('component.includs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\New folder\party\resources\views/component/reserve/index.blade.php ENDPATH**/ ?>