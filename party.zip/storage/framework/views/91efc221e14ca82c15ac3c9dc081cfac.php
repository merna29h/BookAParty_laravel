
<?php $__env->startSection('home'); ?>

<form action=""  method="POST">


<div class="mb-3">
    <label for="exampleInputEmail1" class="form-label"> Phone Number</label>
    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="" name="phone">
  </div> 

  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label"> Phone Number</label>
    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="" name="email">
  </div> 
  
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label"> Number of Ticket</label>
    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="" name="number_ticket">
  </div> 
   
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label"> Approve </label>
    <input type="checkbox" class="form-control" id="exampleInputEmail1" placeholder="" name="approve">
  </div> 
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('component.front end.tecket', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\New folder\party\resources\views/component/front end/tecket.blade.php ENDPATH**/ ?>