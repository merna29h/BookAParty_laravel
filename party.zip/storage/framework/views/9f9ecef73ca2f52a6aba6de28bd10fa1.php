<div class="performar_area black_bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section_title mb-80">
                    <h3 class="wow fadeInRight" data-wow-duration="1s" data-wow-delay=".3s">Performer</h3>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="row">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-6 col-md-6">
                        <div  class="single_performer wow fadeInUp" data-wow-duration="1s" data-wow-delay=".3s">
                            <div data-tilt class="thumb">
                                
                                    
                               
                                <img src="<?php echo e(asset('category/'.$cate->logo)); ?>" alt="" width="350" height="435">
                            </div>
                            <div class="performer_heading">
                                <h4><?php echo e($cate->name); ?></h4>
                                <span><?php echo e($cate->description); ?></span>
                                
                            </div>
                            
                        </div>
                       
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
               
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\laravel\New folder\party\resources\views/component/front end/preformar.blade.php ENDPATH**/ ?>